using Npgsql;
using System.Data;

namespace SanVicenteHospital.Data
{
    public class ApplicationDbContext
    {
        private readonly string _connectionString;

        public ApplicationDbContext(string connectionString)
        {
            _connectionString = connectionString;
        }

        // Open and return a PostgreSQL connection
        public NpgsqlConnection GetConnection()
        {
            var connection = new NpgsqlConnection(_connectionString);
            connection.Open();
            return connection;
        }

        // Execute SELECT queries (returns a DataTable)
        public DataTable ExecuteQuery(string sql, Dictionary<string, object>? parameters = null)
        {
            var table = new DataTable();

            using var connection = GetConnection();
            using var command = new NpgsqlCommand(sql, connection);

            if (parameters != null)
            {
                foreach (var param in parameters)
                    command.Parameters.AddWithValue(param.Key, param.Value);
            }

            using var adapter = new NpgsqlDataAdapter(command);
            adapter.Fill(table);

            return table;
        }

        // Execute INSERT, UPDATE or DELETE statements
        public int ExecuteNonQuery(string sql, Dictionary<string, object>? parameters = null)
        {
            using var connection = GetConnection();
            using var command = new NpgsqlCommand(sql, connection);

            if (parameters != null)
            {
                foreach (var param in parameters)
                    command.Parameters.AddWithValue(param.Key, param.Value);
            }

            return command.ExecuteNonQuery();
        }

        // Execute a scalar query (e.g., COUNT, SUM)
        public object? ExecuteScalar(string sql, Dictionary<string, object>? parameters = null)
        {
            using var connection = GetConnection();
            using var command = new NpgsqlCommand(sql, connection);

            if (parameters != null)
            {
                foreach (var param in parameters)
                    command.Parameters.AddWithValue(param.Key, param.Value);
            }

            return command.ExecuteScalar();
        }
    }
}