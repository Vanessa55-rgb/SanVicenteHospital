using System.ComponentModel.DataAnnotations;

namespace SanVicenteHospital.Models
{
    public class Doctor
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre completo es obligatorio.")]
        [RegularExpression(@"^[a-zA-ZÁÉÍÓÚáéíóúñÑ\s]+$", ErrorMessage = "El nombre solo puede contener letras.")]
        public string FullName { get; set; } = "";

        [Required(ErrorMessage = "El documento de identidad es obligatorio.")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "El documento debe tener exactamente 10 números.")]
        public string DocumentId { get; set; } = "";

        [Required(ErrorMessage = "La edad es obligatoria.")]
        [Range(18, 120, ErrorMessage = "El doctor debe tener 18 años o más.")]
        public int Age { get; set; }

        [Required(ErrorMessage = "El teléfono es obligatorio.")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "El teléfono debe tener exactamente 10 números.")]
        public string Phone { get; set; } = "";

        [Required(ErrorMessage = "El correo electrónico es obligatorio.")]
        [RegularExpression(@"^[\w\.-]+@hospital\.com$", ErrorMessage = "El correo debe pertenecer al dominio @hospital.com.")]
        

        public string Email { get; set; } = "";

        [Required(ErrorMessage = "La especialidad es obligatoria.")]
        public string Specialty { get; set; } = "";
        
        public static readonly string[] AllowedSpecialties = new[]
        {
            "Medicina General",
            "Cardiología",
            "Dermatología",
            "Endocrinología",
            "Ginecología y Obstetricia",
            "Neurología",
            "Pediatría",
            "Psiquiatría",
            "Oftalmología"
        };
    }
}