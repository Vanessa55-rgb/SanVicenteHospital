namespace SanVicenteHospital.Models
{
    public interface IEntity
    {
        int Id { get; set; }
        string GetEntityInfo(); 
    }
}