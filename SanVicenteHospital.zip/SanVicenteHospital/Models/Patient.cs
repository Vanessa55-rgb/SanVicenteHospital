using System.ComponentModel.DataAnnotations;

namespace SanVicenteHospital.Models
{
    public class Patient
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre completo es obligatorio.")]
        [RegularExpression(@"^[a-zA-ZÁÉÍÓÚáéíóúñÑ\s]+$", ErrorMessage = "El nombre solo puede contener letras.")]
        public string FullName { get; set; } = "";

        [Required(ErrorMessage = "El documento de identidad es obligatorio.")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "El documento debe tener exactamente 10 números.")]
        public string DocumentId { get; set; } = "";

        [Required(ErrorMessage = "La edad es obligatoria.")]
        [Range(1, 120, ErrorMessage = "La edad debe ser un número positivo.")]
        public int Age { get; set; }

        [Required(ErrorMessage = "El número de teléfono es obligatorio.")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "El teléfono debe tener exactamente 10 números.")]
        public string Phone { get; set; } = "";

        [Required(ErrorMessage = "El correo electrónico es obligatorio.")]
        [RegularExpression(@"^[\w\.-]+@(gmail|hotmail)\.com$", ErrorMessage = "El correo debe ser de dominio gmail.com o hotmail.com.")]

        public string Email { get; set; } = "";

        [MaxLength(255, ErrorMessage = "La dirección no puede exceder los 255 caracteres.")]
        public string? Address { get; set; }
    }
}