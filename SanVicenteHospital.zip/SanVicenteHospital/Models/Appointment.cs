using System;

namespace SanVicenteHospital.Models
{
    public class Appointment : IEntity
    {
        public int Id { get; set; }

        public int PatientId { get; set; }
        public int DoctorId { get; set; }

        public DateTime Date { get; set; }
        public TimeSpan Time { get; set; }
        public string Reason { get; set; } = string.Empty;
        public string Status { get; set; } = "Scheduled";
        
        public string? PatientName { get; set; }
        public string? DoctorName { get; set; }
        
        public string GetEntityInfo()
        {
            return $"Appointment #{Id} - Patient: {PatientName}, Doctor: {DoctorName}, Date: {Date:yyyy-MM-dd} {Time:hh\\:mm}";
        }
    }
}