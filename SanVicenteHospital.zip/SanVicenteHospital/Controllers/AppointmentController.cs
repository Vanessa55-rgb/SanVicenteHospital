using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SanVicenteHospital.Data;
using SanVicenteHospital.Models;
using System;
using System.Collections.Generic;
using System.Data;

namespace SanVicenteHospital.Controllers
{
    public class AppointmentController : Controller
    {
        private readonly string _connectionString =
            "Host=168.119.183.3;Port=5432;Database=San_Vicente_Vanessa_Hospital;Username=root;Password=s7cq453mt2jnicTaQXKT";

        public IActionResult Index()
        {
            var appointments = new List<Appointment>();
            var db = new ApplicationDbContext(_connectionString);

            try
            {
                string sql = @"
                    SELECT 
                        A.""Id"", A.""Date"", A.""Time"", A.""Reason"", A.""Status"",
                        P.""FullName"" AS ""PatientName"",
                        D.""FullName"" AS ""DoctorName""
                    FROM ""Appointments"" A
                    INNER JOIN ""Patients"" P ON A.""PatientId"" = P.""Id""
                    INNER JOIN ""Doctors"" D ON A.""DoctorId"" = D.""Id""
                    ORDER BY A.""Date"", A.""Time"";";

                DataTable table = db.ExecuteQuery(sql);

                foreach (DataRow row in table.Rows)
                {
                    appointments.Add(new Appointment
                    {
                        Id = (int)row["Id"],
                        Date = (DateTime)row["Date"],
                        Time = (TimeSpan)row["Time"],
                        Reason = row["Reason"].ToString() ?? "",
                        Status = row["Status"].ToString() ?? "Scheduled",
                        PatientName = row["PatientName"].ToString() ?? "",
                        DoctorName = row["DoctorName"].ToString() ?? ""
                    });
                }
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error loading appointments: {ex.Message}";
            }

            return View(appointments);
        }

        public IActionResult Details(int id)
        {
            var db = new ApplicationDbContext(_connectionString);
            Appointment? appointment = null;

            try
            {
                string sql = @"
                    SELECT 
                        A.""Id"", A.""Date"", A.""Time"", A.""Reason"", A.""Status"",
                        P.""FullName"" AS ""PatientName"",
                        D.""FullName"" AS ""DoctorName""
                    FROM ""Appointments"" A
                    INNER JOIN ""Patients"" P ON A.""PatientId"" = P.""Id""
                    INNER JOIN ""Doctors"" D ON A.""DoctorId"" = D.""Id""
                    WHERE A.""Id"" = @Id;";

                var table = db.ExecuteQuery(sql, new Dictionary<string, object> { { "@Id", id } });

                if (table.Rows.Count == 1)
                {
                    var row = table.Rows[0];
                    appointment = new Appointment
                    {
                        Id = (int)row["Id"],
                        Date = (DateTime)row["Date"],
                        Time = (TimeSpan)row["Time"],
                        Reason = row["Reason"].ToString() ?? "",
                        Status = row["Status"].ToString() ?? "Scheduled",
                        PatientName = row["PatientName"].ToString() ?? "",
                        DoctorName = row["DoctorName"].ToString() ?? ""
                    };
                }
                else
                {
                    TempData["Error"] = "Appointment not found.";
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error loading details: {ex.Message}";
                return RedirectToAction("Index");
            }

            return View(appointment);
        }

        public IActionResult Create()
        {
            var db = new ApplicationDbContext(_connectionString);
            ViewBag.PatientList = new SelectList(GetPatients(db), "Id", "FullName");
            ViewBag.DoctorList = new SelectList(GetDoctors(db), "Id", "FullName");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Appointment appointment)
        {
            var db = new ApplicationDbContext(_connectionString);
            try
            {
                if (appointment.PatientId <= 0 || appointment.DoctorId <= 0)
                    throw new Exception("Seleccione un paciente y un médico válidos.");

                string sql = @"INSERT INTO ""Appointments"" 
                    (""PatientId"", ""DoctorId"", ""Date"", ""Time"", ""Reason"", ""Status"") 
                    VALUES (@PatientId, @DoctorId, @Date, @Time, @Reason, @Status);";

                var parameters = new Dictionary<string, object>
                {
                    {"@PatientId", appointment.PatientId},
                    {"@DoctorId", appointment.DoctorId},
                    {"@Date", appointment.Date},
                    {"@Time", appointment.Time},
                    {"@Reason", appointment.Reason},
                    {"@Status", appointment.Status}
                };

                db.ExecuteNonQuery(sql, parameters);
                TempData["Message"] = "Cita creada con éxito!";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error creando cita: {ex.Message}";
                ViewBag.PatientList = new SelectList(GetPatients(db), "Id", "FullName");
                ViewBag.DoctorList = new SelectList(GetDoctors(db), "Id", "FullName");
                return View(appointment);
            }
        }

        public IActionResult Edit(int id)
        {
            var db = new ApplicationDbContext(_connectionString);
            Appointment? appointment = null;

            try
            {
                string sql = @"SELECT * FROM ""Appointments"" WHERE ""Id""=@Id;";
                var table = db.ExecuteQuery(sql, new Dictionary<string, object> { { "@Id", id } });

                if (table.Rows.Count == 1)
                {
                    var row = table.Rows[0];
                    appointment = new Appointment
                    {
                        Id = (int)row["Id"],
                        PatientId = (int)row["PatientId"],
                        DoctorId = (int)row["DoctorId"],
                        Date = (DateTime)row["Date"],
                        Time = (TimeSpan)row["Time"],
                        Reason = row["Reason"].ToString() ?? "",
                        Status = row["Status"].ToString() ?? "Scheduled"
                    };
                }
                else
                {
                    TempData["Error"] = "Cita no encontrada.";
                    return RedirectToAction("Index");
                }

                ViewBag.PatientList = new SelectList(GetPatients(db), "Id", "FullName");
                ViewBag.DoctorList = new SelectList(GetDoctors(db), "Id", "FullName");
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error cargando la cita: {ex.Message}";
                return RedirectToAction("Index");
            }

            return View(appointment);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Appointment appointment)
        {
            var db = new ApplicationDbContext(_connectionString);
            try
            {
                string sql = @"UPDATE ""Appointments"" 
                    SET ""PatientId""=@PatientId, ""DoctorId""=@DoctorId, ""Date""=@Date, 
                        ""Time""=@Time, ""Reason""=@Reason, ""Status""=@Status
                    WHERE ""Id""=@Id;";

                var parameters = new Dictionary<string, object>
                {
                    {"@PatientId", appointment.PatientId},
                    {"@DoctorId", appointment.DoctorId},
                    {"@Date", appointment.Date},
                    {"@Time", appointment.Time},
                    {"@Reason", appointment.Reason},
                    {"@Status", appointment.Status},
                    {"@Id", appointment.Id}
                };

                db.ExecuteNonQuery(sql, parameters);
                TempData["Message"] = "Cita actualizada con éxito!";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error actualizando cita: {ex.Message}";
                ViewBag.PatientList = new SelectList(GetPatients(db), "Id", "FullName");
                ViewBag.DoctorList = new SelectList(GetDoctors(db), "Id", "FullName");
                return View(appointment);
            }
        }

        public IActionResult Delete(int id)
        {
            var db = new ApplicationDbContext(_connectionString);
            try
            {
                string sql = "DELETE FROM \"Appointments\" WHERE \"Id\"=@Id;";
                db.ExecuteNonQuery(sql, new Dictionary<string, object> { { "@Id", id } });
                TempData["Message"] = "Cita eliminada con éxito!";
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error eliminando cita: {ex.Message}";
            }

            return RedirectToAction("Index");
        }
        
        private List<Patient> GetPatients(ApplicationDbContext db)
        {
            string sql = "SELECT \"Id\", \"FullName\" FROM \"Patients\" ORDER BY \"FullName\";";
            var table = db.ExecuteQuery(sql);
            var list = new List<Patient>();

            foreach (DataRow row in table.Rows)
                list.Add(new Patient { Id = (int)row["Id"], FullName = row["FullName"].ToString() ?? "" });

            return list;
        }

        private List<Doctor> GetDoctors(ApplicationDbContext db)
        {
            string sql = "SELECT \"Id\", \"FullName\" FROM \"Doctors\" ORDER BY \"FullName\";";
            var table = db.ExecuteQuery(sql);
            var list = new List<Doctor>();

            foreach (DataRow row in table.Rows)
                list.Add(new Doctor { Id = (int)row["Id"], FullName = row["FullName"].ToString() ?? "" });

            return list;
        }
    }
}