using Microsoft.AspNetCore.Mvc;
using SanVicenteHospital.Data;
using SanVicenteHospital.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;

namespace SanVicenteHospital.Controllers
{
    public class PatientController : Controller
    {
        private readonly string _connectionString =
            "Host=168.119.183.3;Port=5432;Database=San_Vicente_Vanessa_Hospital;Username=root;Password=s7cq453mt2jnicTaQXKT";
        
        public IActionResult Index(string? search)
        {
            var patients = GetAllPatients();

            if (!string.IsNullOrWhiteSpace(search))
            {
                patients = patients
                    .Where(p =>
                        p.FullName.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                        p.DocumentId.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                        p.Email.Contains(search, StringComparison.OrdinalIgnoreCase))
                    .ToList();
            }

            return View(patients);
        }
        
        public IActionResult Details(int id)
        {
            var patient = GetPatientById(id);
            if (patient == null)
            {
                TempData["Error"] = "Paciente no encontrado.";
                return RedirectToAction("Index");
            }
            return View(patient);
        }
        
        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Patient patient)
        {
            if (!ModelState.IsValid)
                return View(patient);
            
            var existing = GetAllPatients();
            if (existing.Any(p => p.DocumentId == patient.DocumentId))
            {
                ModelState.AddModelError("DocumentId", "Ya existe un paciente con este documento.");
                return View(patient);
            }

            if (existing.Any(p => p.Email.Equals(patient.Email, StringComparison.OrdinalIgnoreCase)))
            {
                ModelState.AddModelError("Email", "Ya existe un paciente con este correo electrónico.");
                return View(patient);
            }

            try
            {
                var db = new ApplicationDbContext(_connectionString);
                string sql = @"INSERT INTO ""Patients""
                    (""FullName"", ""DocumentId"", ""Email"", ""Age"", ""Address"", ""Phone"")
                    VALUES (@FullName, @DocumentId, @Email, @Age, @Address, @Phone);";

                var parameters = new Dictionary<string, object>
                {
                    {"@FullName", patient.FullName},
                    {"@DocumentId", patient.DocumentId},
                    {"@Email", patient.Email},
                    {"@Age", patient.Age},
                    {"@Address", patient.Address ?? ""},
                    {"@Phone", patient.Phone}
                };

                db.ExecuteNonQuery(sql, parameters);
                TempData["Message"] = "Paciente registrado exitosamente.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error al registrar paciente: {ex.Message}";
                return View(patient);
            }
        }

        public IActionResult Edit(int id)
        {
            var patient = GetPatientById(id);
            if (patient == null)
            {
                TempData["Error"] = "Paciente no encontrado.";
                return RedirectToAction("Index");
            }
            return View(patient);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Patient patient)
        {
            if (!ModelState.IsValid)
                return View(patient);

            try
            {
                var db = new ApplicationDbContext(_connectionString);
                string sql = @"UPDATE ""Patients"" SET
                    ""FullName""=@FullName,
                    ""DocumentId""=@DocumentId,
                    ""Email""=@Email,
                    ""Age""=@Age,
                    ""Address""=@Address,
                    ""Phone""=@Phone
                    WHERE ""Id""=@Id;";

                var parameters = new Dictionary<string, object>
                {
                    {"@Id", patient.Id},
                    {"@FullName", patient.FullName},
                    {"@DocumentId", patient.DocumentId},
                    {"@Email", patient.Email},
                    {"@Age", patient.Age},
                    {"@Address", patient.Address ?? ""},
                    {"@Phone", patient.Phone}
                };

                db.ExecuteNonQuery(sql, parameters);
                TempData["Message"] = "Paciente actualizado correctamente.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error al actualizar paciente: {ex.Message}";
                return View(patient);
            }
        }
        
        public IActionResult Delete(int id)
        {
            var patient = GetPatientById(id);
            if (patient == null)
            {
                TempData["Error"] = "Paciente no encontrado.";
                return RedirectToAction("Index");
            }
            return View(patient);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            try
            {
                var db = new ApplicationDbContext(_connectionString);
                string sql = "DELETE FROM \"Patients\" WHERE \"Id\"=@Id;";
                var parameters = new Dictionary<string, object> { { "@Id", id } };
                db.ExecuteNonQuery(sql, parameters);

                TempData["Message"] = "Paciente eliminado exitosamente.";
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error al eliminar paciente: {ex.Message}";
            }

            return RedirectToAction("Index");
        }


        private Patient? GetPatientById(int id)
        {
            var db = new ApplicationDbContext(_connectionString);
            string sql = "SELECT * FROM \"Patients\" WHERE \"Id\"=@Id;";
            var parameters = new Dictionary<string, object> { { "@Id", id } };
            var table = db.ExecuteQuery(sql, parameters);

            if (table.Rows.Count == 0) return null;

            var row = table.Rows[0];
            return new Patient
            {
                Id = (int)row["Id"],
                FullName = row["FullName"].ToString() ?? "",
                DocumentId = row["DocumentId"].ToString() ?? "",
                Email = row["Email"].ToString() ?? "",
                Age = (int)row["Age"],
                Address = row["Address"].ToString() ?? "",
                Phone = row["Phone"].ToString() ?? ""
            };
        }

        private List<Patient> GetAllPatients()
        {
            var db = new ApplicationDbContext(_connectionString);
            string sql = "SELECT * FROM \"Patients\";";
            var table = db.ExecuteQuery(sql);
            return table.Rows.Cast<DataRow>().Select(row => new Patient
            {
                Id = (int)row["Id"],
                FullName = row["FullName"].ToString() ?? "",
                DocumentId = row["DocumentId"].ToString() ?? "",
                Email = row["Email"].ToString() ?? "",
                Age = (int)row["Age"],
                Address = row["Address"].ToString() ?? "",
                Phone = row["Phone"].ToString() ?? ""
            }).ToList();
        }
    }
}