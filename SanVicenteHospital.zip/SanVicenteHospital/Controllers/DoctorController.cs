using Microsoft.AspNetCore.Mvc;
using SanVicenteHospital.Data;
using SanVicenteHospital.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace SanVicenteHospital.Controllers
{
    public class DoctorController : Controller
    {
        private readonly string _connectionString =
            "Host=168.119.183.3;Port=5432;Database=San_Vicente_Vanessa_Hospital;Username=root;Password=s7cq453mt2jnicTaQXKT";
        
        private static readonly string[] AllowedSpecialties = new[]
        {
            "Medicina General",
            "Cardiología",
            "Dermatología",
            "Endocrinología",
            "Ginecología y Obstetricia",
            "Neurología",
            "Pediatría",
            "Psiquiatría",
            "Oftalmología"
        };
        
        public IActionResult Index(string? specialty, string? search)
        {
            var doctors = new List<Doctor>();
            var db = new ApplicationDbContext(_connectionString);

            try
            {
                string sql = "SELECT * FROM \"Doctors\" ORDER BY \"FullName\";";
                DataTable table = db.ExecuteQuery(sql);

                foreach (DataRow row in table.Rows)
                {
                    doctors.Add(new Doctor
                    {
                        Id = Convert.ToInt32(row["Id"]),
                        FullName = row["FullName"]?.ToString() ?? "",
                        DocumentId = row["DocumentId"]?.ToString() ?? "",
                        Email = row["Email"]?.ToString() ?? "",
                        Age = row["Age"] == DBNull.Value ? 0 : Convert.ToInt32(row["Age"]),
                        Phone = row["Phone"]?.ToString() ?? "",
                        Specialty = row["Specialty"]?.ToString() ?? ""
                    });
                }
                
                if (!string.IsNullOrWhiteSpace(specialty) && specialty != "Todas")
                {
                    doctors = doctors
                        .Where(d => d.Specialty.Equals(specialty, StringComparison.OrdinalIgnoreCase))
                        .ToList();
                }
                
                if (!string.IsNullOrWhiteSpace(search))
                {
                    doctors = doctors
                        .Where(d =>
                            d.FullName.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                            d.DocumentId.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                            d.Email.Contains(search, StringComparison.OrdinalIgnoreCase))
                        .ToList();
                }

                ViewBag.Specialties = AllowedSpecialties;
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error al cargar la lista de doctores: {ex.Message}";
            }

            return View(doctors);
        }
        
        public IActionResult Details(int id)
        {
            var doctor = GetDoctorById(id);
            if (doctor == null)
            {
                TempData["Error"] = "Doctor no encontrado.";
                return RedirectToAction("Index");
            }
            return View(doctor);
        }
        
        public IActionResult Create()
        {
            ViewBag.Specialties = AllowedSpecialties;
            return View();
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Doctor doctor)
        {
            if (doctor == null)
            {
                TempData["Error"] = "Datos inválidos.";
                return RedirectToAction("Index");
            }

            if (doctor.Age < 18)
            {
                ModelState.AddModelError("Age", "El doctor debe ser mayor de 18 años.");
                ViewBag.Specialties = AllowedSpecialties;
                return View(doctor);
            }

            try
            {
                var db = new ApplicationDbContext(_connectionString);
                string sql = @"INSERT INTO ""Doctors"" 
                               (""FullName"", ""DocumentId"", ""Email"", ""Age"", ""Phone"", ""Specialty"") 
                               VALUES (@FullName, @DocumentId, @Email, @Age, @Phone, @Specialty);";

                var parameters = new Dictionary<string, object>
                {
                    {"@FullName", doctor.FullName},
                    {"@DocumentId", doctor.DocumentId},
                    {"@Email", doctor.Email ?? ""},
                    {"@Age", doctor.Age},
                    {"@Phone", doctor.Phone ?? ""},
                    {"@Specialty", doctor.Specialty ?? ""}
                };

                db.ExecuteNonQuery(sql, parameters);
                TempData["Message"] = "Doctor registrado con éxito.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error al registrar el doctor: {ex.Message}";
                ViewBag.Specialties = AllowedSpecialties;
                return View(doctor);
            }
        }
        
        public IActionResult Edit(int id)
        {
            var doctor = GetDoctorById(id);
            if (doctor == null)
            {
                TempData["Error"] = "Doctor no encontrado.";
                return RedirectToAction("Index");
            }
            ViewBag.Specialties = AllowedSpecialties;
            return View(doctor);
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Doctor doctor)
        {
            if (doctor == null)
            {
                TempData["Error"] = "Datos inválidos.";
                return RedirectToAction("Index");
            }

            if (doctor.Age < 18)
            {
                ModelState.AddModelError("Age", "El doctor debe ser mayor de 18 años.");
                ViewBag.Specialties = AllowedSpecialties;
                return View(doctor);
            }

            try
            {
                var db = new ApplicationDbContext(_connectionString);
                string sql = @"UPDATE ""Doctors"" 
                               SET ""FullName""=@FullName, ""DocumentId""=@DocumentId, ""Email""=@Email,
                                   ""Age""=@Age, ""Phone""=@Phone, ""Specialty""=@Specialty
                               WHERE ""Id""=@Id;";

                var parameters = new Dictionary<string, object>
                {
                    {"@FullName", doctor.FullName},
                    {"@DocumentId", doctor.DocumentId},
                    {"@Email", doctor.Email ?? ""},
                    {"@Age", doctor.Age},
                    {"@Phone", doctor.Phone ?? ""},
                    {"@Specialty", doctor.Specialty ?? ""},
                    {"@Id", doctor.Id}
                };

                db.ExecuteNonQuery(sql, parameters);
                TempData["Message"] = "Doctor actualizado con éxito.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error al actualizar doctor: {ex.Message}";
                ViewBag.Specialties = AllowedSpecialties;
                return View(doctor);
            }
        }
        
        public IActionResult Delete(int id)
        {
            var doctor = GetDoctorById(id);
            if (doctor == null)
            {
                TempData["Error"] = "Doctor no encontrado.";
                return RedirectToAction("Index");
            }
            return View(doctor);
        }
        
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var db = new ApplicationDbContext(_connectionString);

            try
            {
                string sql = "DELETE FROM \"Doctors\" WHERE \"Id\"=@Id;";
                var parameters = new Dictionary<string, object> { { "@Id", id } };
                db.ExecuteNonQuery(sql, parameters);
                TempData["Message"] = "Doctor eliminado exitosamente.";
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error al eliminar doctor: {ex.Message}";
            }

            return RedirectToAction("Index");
        }
        
        private Doctor? GetDoctorById(int id)
        {
            var db = new ApplicationDbContext(_connectionString);
            string sql = "SELECT * FROM \"Doctors\" WHERE \"Id\"=@Id;";
            var parameters = new Dictionary<string, object> { { "@Id", id } };
            var table = db.ExecuteQuery(sql, parameters);

            if (table.Rows.Count == 0)
                return null;

            var row = table.Rows[0];
            return new Doctor
            {
                Id = Convert.ToInt32(row["Id"]),
                FullName = row["FullName"]?.ToString() ?? "",
                DocumentId = row["DocumentId"]?.ToString() ?? "",
                Email = row["Email"]?.ToString() ?? "",
                Age = row["Age"] == DBNull.Value ? 0 : Convert.ToInt32(row["Age"]),
                Phone = row["Phone"]?.ToString() ?? "",
                Specialty = row["Specialty"]?.ToString() ?? ""
            };
        }
    }
}
